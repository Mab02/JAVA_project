package simulateur_robot;

public class Door extends Component { /* egalement reference de room*/

	private boolean open ;
	
	
}
