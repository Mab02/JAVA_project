package simulateur_robot;

public class Battery {
	private Robot robot;/*reference bidirectionnelle avec le robot */

}
