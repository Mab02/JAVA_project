package simulateur_robot;

public class Booth extends Component{

}
