package simulateur_robot;

public abstract class Dimension {

}
