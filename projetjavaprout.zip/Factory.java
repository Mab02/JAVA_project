package simulateur_robot;
import java.util.ArrayList;

public class Factory {
	private ArrayList<Component> componentList; /*reference à component*/

}
