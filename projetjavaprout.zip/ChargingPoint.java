package simulateur_robot;

public class ChargingPoint extends Component{

}
