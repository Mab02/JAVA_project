package simulateur_robot;

public class Robot extends Component{
	private Battery battery;/*reference bidirectionnelle avec le robot */

}
