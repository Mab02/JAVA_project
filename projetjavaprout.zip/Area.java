package simulateur_robot;

public class Area extends Component{ /*egalement refer room*/

}
