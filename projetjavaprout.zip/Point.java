package simulateur_robot;

public class Point {
	private int xcoord;
	private int ycoord;

}
Point(int x0,
int y0) {
x = x0;
y = y0;
}