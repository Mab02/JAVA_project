package simulateur_robot;

public abstract class Component {
	private String id;

	private int xcoord;

	private int ycoord;
	
	private Dimension dimension;


public String getId() {

return id;

}
public int getxcoord() {

return xcoord;

}
public int getycoord() {

return ycoord;

}}
