package simulateur_robot;

public class Puck extends Component{ /*egalement refer room*/

}
